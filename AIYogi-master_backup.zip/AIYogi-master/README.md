# AIYogi
The files in javascript and html belong to the browser implementation of posenet in JS
