List<String> beginnerAsanas = [
  'Trikonasana',
  'Vrikshasana',
  'Virbhadrasana',
  'Bhujangasana',
  'Sukhasana',
  'Tadasana'
];

List<String> intermediateAsanas = [
  'Dhanurasana',
  'Padhastasana',
  'Ustrasana',
  'Halasana',
  'Sarvangasana'
];

List<String> advanceAsanas = [
  'Bakasana',
  'Mayurasana',
  'Sirsasana',
];
